set -eu
mkdir -p /work/capture
/opt/dea/bin/investigation-timer /work/capture/build-1.json /work/capture/build-1.stdout /work/capture/build-1.stderr 600 /opt/dea/bin/l1c-stage1 --build --c-compiler clang --c-options=-O0 --no-auto-prepare --project-root /input -o /work/hello.out /input/hello.l1
/work/hello.out > /work/capture/build-1.program
/opt/dea/bin/investigation-timer /work/capture/build-2.json /work/capture/build-2.stdout /work/capture/build-2.stderr 600 /opt/dea/bin/l1c-stage1 --build --c-compiler clang --c-options=-O0 --no-auto-prepare --project-root /input -o /work/hello.out /input/hello.l1
/work/hello.out > /work/capture/build-2.program
cp /work/capture/* /results/
cp /opt/dea/investigation/image-build-*.stderr /results/
